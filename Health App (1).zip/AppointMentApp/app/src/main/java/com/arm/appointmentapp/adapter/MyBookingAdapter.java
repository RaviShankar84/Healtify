package com.arm.appointmentapp.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.arm.appointmentapp.R;
import com.arm.appointmentapp.databinding.ItemMyBookingsBinding;
import com.arm.appointmentapp.model.MyBokingModel;
import com.arm.appointmentapp.model.UserModel;
import com.bumptech.glide.Glide;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class MyBookingAdapter extends RecyclerView.Adapter<MyBookingAdapter.MyBookingViewHolder> {


    Context mContext;
    ArrayList<MyBokingModel> bokingModelArrayList;
    OnItemClickListener onItemClickListener;


    public MyBookingAdapter(Context mContext, ArrayList<MyBokingModel> bokingModelArrayList, OnItemClickListener onItemClickListener) {
        this.mContext = mContext;
        this.bokingModelArrayList = bokingModelArrayList;
        this.onItemClickListener = onItemClickListener;
    }

    @NonNull
    @Override
    public MyBookingViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mContext).inflate(R.layout.item_my_bookings, parent, false);
        return new MyBookingViewHolder(view);
    }

    @Override
    public int getItemCount() {
        return bokingModelArrayList.size();
    }

    @Override
    public void onBindViewHolder(@NonNull MyBookingViewHolder holder, int position) {
        MyBokingModel myBokingModel = bokingModelArrayList.get(position);
        holder.binding.categorName.setText(myBokingModel.getCategoryName());
        holder.binding.name.setText(myBokingModel.getName());
        holder.binding.description.setText(myBokingModel.getDescription());
        holder.binding.time.setText(myBokingModel.getBookingTime());
        holder.binding.dateTime.setText(myBokingModel.getDate());



        Glide.with(mContext)
                .load(myBokingModel.getProfileImage())
                .centerCrop()
                .placeholder(R.drawable.ic_user_profile_image)
                .into(holder.binding.profileImage);

        holder.binding.cancelBoking.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onItemClickListener.onCancelBookClick(myBokingModel);
            }
        });
    }

    public static class MyBookingViewHolder extends RecyclerView.ViewHolder {
        ItemMyBookingsBinding binding;

        public MyBookingViewHolder(@NonNull View itemView) {
            super(itemView);
            binding = ItemMyBookingsBinding.bind(itemView);
        }
    }

    public interface OnItemClickListener {
        void onCancelBookClick(MyBokingModel myBokingModel);
    }
}
