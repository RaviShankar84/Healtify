package com.arm.appointmentapp.activity;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Toast;

import com.arm.appointmentapp.R;
import com.arm.appointmentapp.databinding.ActivityRegisterBinding;
import com.arm.appointmentapp.model.CategoryModel;
import com.arm.appointmentapp.model.UserModel;
import com.arm.appointmentapp.prefrence.PrefUtil;
import com.arm.appointmentapp.utils.Utils;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QuerySnapshot;
import com.kaopiz.kprogresshud.KProgressHUD;

import java.util.ArrayList;


public class RegisterActivity extends AppCompatActivity {

    String[] professionArray = {"Doctors", "Gym Trainer", "Sports"};
    ActivityRegisterBinding binding;
    FirebaseAuth firebaseAuth;
    KProgressHUD progressHUD;
    ArrayList<String> categoryList;
    String mCetagoryName, mProfessionName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityRegisterBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        if (PrefUtil.getInstance(this).getUserApp().equals("userApp")) {
            binding.mProfView.setVisibility(View.GONE);
        } else {
            binding.mProfView.setVisibility(View.VISIBLE);
        }

        firebaseAuth = FirebaseAuth.getInstance();
        categoryList = new ArrayList<>();

        progressHUD = Utils.intiDialog(RegisterActivity.this, progressHUD);

        binding.loginTv.setOnClickListener(view -> startActivity(new Intent(RegisterActivity.this, LoginActivity.class)));

        binding.registerBtn.setOnClickListener(view -> {
            String userEmail = binding.userEmail.getText().toString();
            String userName = binding.userName.getText().toString();
            String userPassword = binding.userPassword.getText().toString();
            String userPhoneNmber = binding.phoneNumber.getText().toString();
            String description = binding.description.getText().toString();

            if (userEmail.isEmpty()) {
                Toast.makeText(RegisterActivity.this, "enter email", Toast.LENGTH_SHORT).show();
                return;
            }

            if (userName.isEmpty()) {
                Toast.makeText(RegisterActivity.this, "enter name", Toast.LENGTH_SHORT).show();
                return;
            }

            if (userPassword.isEmpty()) {
                Toast.makeText(RegisterActivity.this, "enter password", Toast.LENGTH_SHORT).show();
                return;

            }

            if (userPassword.isEmpty()) {
                Toast.makeText(RegisterActivity.this, "enter phone", Toast.LENGTH_SHORT).show();
                return;

            }


            if (!Utils.isValidEmailId(userEmail)) {
                Toast.makeText(RegisterActivity.this, "please enter valid email", Toast.LENGTH_SHORT).show();
                return;
            }

            registerNewUser(userEmail, userName, userPassword, userPhoneNmber, description);
        });

        setProfessionList();
    }


    private void registerNewUser(String userEmail, String userName, String userPassword, String userPhoneNmber, String description) {
        progressHUD.show();
        UserModel userModel = new UserModel();
        firebaseAuth.createUserWithEmailAndPassword(userEmail, userPassword).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                progressHUD.dismiss();
                if (task.isSuccessful()) {
                    String id = FirebaseAuth.getInstance().getUid();
                    userModel.setUserId(id);
                    userModel.setEmail(userEmail);
                    userModel.setName(userName);
                    userModel.setPassword(userPassword);
                    userModel.setPhoneUmber(userPhoneNmber);
                    userModel.setProfession(mProfessionName);
                    userModel.setCategory(mCetagoryName);
                    userModel.setUserDescription(description);
                    Toast.makeText(RegisterActivity.this, "Register Success", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(RegisterActivity.this, OtpVerificationActivity.class);
                    intent.putExtra("userModel", userModel);
                    startActivity(intent);
                    finish();
                } else {
                    Toast.makeText(RegisterActivity.this, "Login Failed" + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                }
            }
        }).addOnFailureListener(e -> {
            progressHUD.dismiss();
            Log.d("SingIn", ": Exception" + e.getMessage());
        });
    }

    private void setProfessionList() {
        ArrayAdapter<String> mProfessionAdapter = new ArrayAdapter<>(this, R.layout.spinner_item, professionArray);
        binding.mProfessionList.setAdapter(mProfessionAdapter);
        binding.mProfessionList.setOnItemClickListener((adapterView, view, i, l) -> {
            mProfessionName = adapterView.getItemAtPosition(i).toString();
            Toast.makeText(RegisterActivity.this, mProfessionName, Toast.LENGTH_SHORT).show();
            categoryList.clear();
            setUpCategoryList(mProfessionName);
        });

    }

    private void setUpCategoryList(String profession) {
        Log.d("setUpCategoryList", profession);
        FirebaseFirestore.getInstance().collection(profession).addSnapshotListener((value, error) -> {
            categoryList.clear();
            if (!value.isEmpty()) {
                for (DocumentSnapshot snapshot : value.getDocuments()) {
                    String categoryModel = snapshot.getId().toString();
                    categoryList.add(categoryModel);
                }
                for (String categoryModel : categoryList) {
                    Log.d("setUpCategoryList", "size: " + categoryList.size());
                    Log.d("setUpCategoryList", "name: " + categoryList.toString());
                }
                setCategoryAdapter(categoryList);
            }
        });
    }

    private void setCategoryAdapter(ArrayList<String> arrayList) {
        ArrayAdapter<String> mCategoryAdapter = new ArrayAdapter<>(this, R.layout.spinner_item, arrayList);
        binding.mCategoryList.setAdapter(mCategoryAdapter);
        binding.mCategoryList.setOnItemClickListener((adapterView, view, i, l) -> {
            mCetagoryName = adapterView.getItemAtPosition(i).toString();
            Toast.makeText(RegisterActivity.this, mCetagoryName, Toast.LENGTH_SHORT).show();
        });
    }
}