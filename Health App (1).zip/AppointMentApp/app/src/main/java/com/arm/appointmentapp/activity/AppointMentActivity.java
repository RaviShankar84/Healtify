package com.arm.appointmentapp.activity;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.format.DateFormat;
import android.util.Log;
import android.view.View;
import android.widget.TimePicker;
import android.widget.Toast;

import com.arm.appointmentapp.databinding.ActivityAppointMentBinding;
import com.arm.appointmentapp.model.MyApointMentModel;
import com.arm.appointmentapp.model.MyBokingModel;
import com.arm.appointmentapp.model.UserModel;
import com.arm.appointmentapp.utils.DatePicker;
import com.arm.appointmentapp.utils.Utils;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.type.DateTime;
import com.kaopiz.kprogresshud.KProgressHUD;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Objects;

public class AppointMentActivity extends AppCompatActivity implements DatePickerDialog.OnDateSetListener {

    ActivityAppointMentBinding _binding;
    UserModel _userModel;
    String name;
    FirebaseFirestore firebaseFirestore;
    KProgressHUD progressHUD;
    int mMinutes, mHours;
    String fromBookingTime, toBookingTime, bookingDate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        _binding = ActivityAppointMentBinding.inflate(getLayoutInflater());
        setContentView(_binding.getRoot());

        progressHUD = Utils.intiDialog(this, progressHUD);
        Intent intent = getIntent();
        if (intent != null) {
            _userModel = (UserModel) intent.getSerializableExtra("userModel");
            name = intent.getStringExtra("name");

        }
        listners();


    }

    public void bookAppointMent() {
        // Todo __________________________________________________FireBase Code here________________________________________________

        FirebaseFirestore fireStore = FirebaseFirestore.getInstance();
        CollectionReference collectionReference = fireStore.collection("MyBookings").document((FirebaseAuth.getInstance().getUid())).collection("bookings");
        String docId = collectionReference.document().getId();
        String patientId = FirebaseAuth.getInstance().getUid();


        if (fromBookingTime == null) {
            Toast.makeText(this, "please select time", Toast.LENGTH_SHORT).show();
            return;
        }

        if (toBookingTime == null) {
            Toast.makeText(this, "please select to time", Toast.LENGTH_SHORT).show();
            return;
        }


        if (bookingDate == null) {
            Toast.makeText(this, "please selection date", Toast.LENGTH_SHORT).show();
            return;
        }

        progressHUD.show();
        String bookingTime = fromBookingTime + " To " + toBookingTime;
        MyBokingModel myBokingModel = new MyBokingModel(docId, _userModel.getName(), _userModel.getCategory(), _userModel.getProfession(), _userModel.getUserDescription(), _userModel.getProfileImage(), patientId, _userModel.getUserId(), name, bookingTime, bookingDate);

        collectionReference.document(docId).set(myBokingModel).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void unused) {
                myAppointMent(myBokingModel);
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                progressHUD.dismiss();
                Toast.makeText(AppointMentActivity.this, e.getMessage() + "", Toast.LENGTH_SHORT).show();
            }
        });

    }

    private void myAppointMent(MyBokingModel myBokingModel) {
        FirebaseFirestore fireStore = FirebaseFirestore.getInstance();
        CollectionReference collectionReference = fireStore.collection("MyAppointMents").document((myBokingModel.getDoctorId())).collection("allPatientsAppointMents");
        String docId = collectionReference.document().getId();
        String patientId = FirebaseAuth.getInstance().getUid();
        MyApointMentModel model = new MyApointMentModel(docId, myBokingModel.getPatientName(), myBokingModel.getProfileImage(), patientId, myBokingModel.getBookingTime(), myBokingModel.getDate());
        collectionReference.document(docId).set(model).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                progressHUD.dismiss();
                Toast.makeText(AppointMentActivity.this, "Appointment Success Booked", Toast.LENGTH_SHORT).show();

            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                progressHUD.dismiss();
            }
        });
    }

    void listners() {
        _binding.btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                bookAppointMent();
            }
        });


        _binding.backIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

        _binding.dateBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DatePicker datePicker = new DatePicker();
                datePicker.show(getSupportFragmentManager(), "DATE PICK");
            }
        });

        _binding.timeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                TimePickerDialog timePickerDialog = new TimePickerDialog(AppointMentActivity.this, new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker timePicker, int hours, int minutes) {
                        mHours = hours;
                        mMinutes = minutes;
                        Calendar calendar = Calendar.getInstance();
                        calendar.set(0, 0, 0, mHours, mMinutes);
                        fromBookingTime = DateFormat.format("hh:mm: aa", calendar).toString();
                        _binding.timeTv.setText("from " + fromBookingTime);


                    }
                }, 12, 0, false);
                timePickerDialog.updateTime(mHours, mMinutes);
                timePickerDialog.show();


            }
        });

        _binding.timeToBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                TimePickerDialog timePickerDialog = new TimePickerDialog(AppointMentActivity.this, new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker timePicker, int hours, int minutes) {
                        mHours = hours;
                        mMinutes = minutes;
                        Calendar calendar = Calendar.getInstance();
                        calendar.set(0, 0, 0, mHours, mMinutes);
                        toBookingTime = DateFormat.format("hh:mm: aa", calendar).toString();
                        _binding.timeToTv.setText("To " + toBookingTime);

                    }
                }, 12, 0, false);
                timePickerDialog.updateTime(mHours, mMinutes);
                timePickerDialog.show();


            }
        });
    }


    @Override
    public void onDateSet(android.widget.DatePicker view, int year, int month, int dayOfMonth) {
        int mMonth = month + 1;
        String date = dayOfMonth + "/" + mMonth + "/" + year;
        _binding.dateTv.setText(date);
        bookingDate = date;

    }


  /*  private void setUpRecyclerView() {
        progressHUD.show();
        FirebaseFirestore.getInstance().collection("MyAppointMents").document(FirebaseAuth.getInstance().getUid()).collection("allPatientsAppointMents").addSnapshotListener(new EventListener<QuerySnapshot>() {
            @Override
            public void onEvent(@Nullable QuerySnapshot value, @Nullable FirebaseFirestoreException error) {
                progressHUD.dismiss();
                if (!value.isEmpty()) {
                    myApointMentModelArrayList.clear();
                    for (DocumentSnapshot documentSnapshot : value.getDocuments()) {
                        MyApointMentModel myApointMentModel = documentSnapshot.toObject(MyApointMentModel.class);
                        myApointMentModelArrayList.add(myApointMentModel);
                    }
                    binding.myBookingList.setAdapter(myApointMentAdapter);
                    myApointMentAdapter.notifyDataSetChanged();
                    Log.d("SetUpRecyclerView", "Size: " + myApointMentModelArrayList.size());
                    binding.empty.setVisibility(View.GONE);

                } else {
                    binding.empty.setVisibility(View.VISIBLE);
                    Log.d("SetUpRecyclerView", "EMPTY ERROR: ");
                }
            }
        });

    }*/


}