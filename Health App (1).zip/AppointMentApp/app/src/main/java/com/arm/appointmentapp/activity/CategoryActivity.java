package com.arm.appointmentapp.activity;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.PopupMenu;
import android.widget.Toast;

import com.arm.appointmentapp.R;
import com.arm.appointmentapp.adapter.CategoryAdapter;
import com.arm.appointmentapp.adapter.ProfessionsAdapter;
import com.arm.appointmentapp.databinding.ActivityCategoryBinding;
import com.arm.appointmentapp.model.CategoryModel;
import com.arm.appointmentapp.model.ProfessionModel;
import com.arm.appointmentapp.model.UserModel;
import com.bumptech.glide.Glide;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QuerySnapshot;

import org.checkerframework.checker.units.qual.C;

import java.util.ArrayList;
import java.util.Objects;

public class CategoryActivity extends AppCompatActivity {

    ActivityCategoryBinding binding;
    CategoryAdapter adapter;
    FirebaseFirestore firebaseFirestore;
    String mProfessionName;
    ArrayList<String> categoryArrayList;
    ArrayList<UserModel> userModelArrayList;
    String userName;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityCategoryBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.recylerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));

        firebaseFirestore = FirebaseFirestore.getInstance();
        categoryArrayList = new ArrayList<>();
        userModelArrayList = new ArrayList<>();

        Intent intent = getIntent();
        if (intent != null) {
            mProfessionName = intent.getStringExtra("mProfessionName");
        }

        // category list
        setUpCategoryList(mProfessionName);


        binding.mSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(CategoryActivity.this, SearchActivity.class);
                intent.putExtra("professionList", userModelArrayList);
                startActivity(intent);
            }
        });

        binding.mMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showPopupMenu(view);
            }
        });


    }

    private void setUpProfessionRecylerView(String mCategoryName) {

        FirebaseFirestore.getInstance().collection("users").addSnapshotListener(new EventListener<QuerySnapshot>() {
            @Override
            public void onEvent(@Nullable QuerySnapshot value, @Nullable FirebaseFirestoreException error) {
                userModelArrayList.clear();
                UserModel userModel = null;
                for (DocumentSnapshot documentSnapshot : value.getDocuments()) {
                    userModel = documentSnapshot.toObject(UserModel.class);
                    try {
                        setUserProfile(userModel);
                        if (userModel.getCategory().equals(mCategoryName)) {
                            userModelArrayList.add(userModel);
                        }
                    } catch (Exception ignored) {
                        ignored.printStackTrace();
                    }
                }


                ProfessionsAdapter professionsAdapter = new ProfessionsAdapter(CategoryActivity.this, userModelArrayList, new ProfessionsAdapter.OnProfessionItemClickListener() {
                    @Override
                    public void onItemClick(UserModel professionModel) {
                        Intent intent = new Intent(CategoryActivity.this, DetailActivity.class);
                        intent.putExtra("userModel", professionModel);
                        intent.putExtra("name", userName);
                        intent.putExtra("profile", "");
                        startActivity(intent);
                    }
                });
                binding.mPRecylerView.setAdapter(professionsAdapter);

            }
        });

    }

    private void setUserProfile(UserModel userModel) {
        if (Objects.equals(FirebaseAuth.getInstance().getUid(), userModel.getUserId())) {
            Glide.with(CategoryActivity.this)
                    .load(userModel.getProfileImage())
                    .centerCrop()
                    .placeholder(R.drawable.ic_user_profile_image)
                    .into(binding.profileImage);
            userName = userModel.getName();
            binding.mUserName.setText(userModel.getName());
        }
    }


    private void setUpCategoryList(String mProfessionName) {
        Log.d("setUpCategoryList", mProfessionName);
        FirebaseFirestore.getInstance().collection(mProfessionName).addSnapshotListener((value, error) -> {
            categoryArrayList.clear();
            if (!value.isEmpty()) {
                for (DocumentSnapshot snapshot : value.getDocuments()) {
                    String categoryModel = snapshot.getId().toString();
                    categoryArrayList.add(categoryModel);
                }
                for (String categoryModel : categoryArrayList) {
                    Log.d("setUpCategoryList", "size: " + categoryArrayList.size());
                    Log.d("setUpCategoryList", "name: " + categoryArrayList.toString());
                }


                setCategoryAdapter(categoryArrayList);
                //profession list
                setUpProfessionRecylerView(categoryArrayList.get(0));

            }
        });
    }


    private void setCategoryAdapter(ArrayList<String> arrayList) {
        adapter = new CategoryAdapter(CategoryActivity.this, categoryArrayList, new CategoryAdapter.OnCategoryClickItem() {
            @Override
            public void onClickCategoryItem(String mCategoryName, int pos) {
                setUpProfessionRecylerView(mCategoryName);
            }
        });
        binding.recylerView.setAdapter(adapter);
        adapter.notifyDataSetChanged();
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.user_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    private void showPopupMenu(View view) {
        PopupMenu popupMenu = new PopupMenu(CategoryActivity.this, view);
        popupMenu.getMenuInflater().inflate(R.menu.user_menu, popupMenu.getMenu());

        popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem menuItem) {

                switch (menuItem.getItemId()) {

                    case R.id.logOut:
                        FirebaseAuth.getInstance().signOut();
                        startActivity(new Intent(CategoryActivity.this, FirstActivity.class));
                        finish();
                        return true;


                    case R.id.myBooking:
                        startActivity(new Intent(CategoryActivity.this, MyBokingsActivity.class));
                        return true;
                }
                return false;
            }
        });
        popupMenu.show();
    }
}