package com.arm.appointmentapp.model;

import java.io.Serializable;

public class UserModel implements Serializable {

    private String email;
    private String userId;
    private String name;
    private String profileImage;
    private String password;
    private String profession;
    private String category;
    private String phoneUmber;
    private String userDescription;

    public UserModel() {

    }


    public String getUserDescription() {
        return userDescription;
    }

    public void setUserDescription(String userDescription) {
        this.userDescription = userDescription;
    }

    public String getPhoneUmber() {
        return phoneUmber;
    }

    public void setPhoneUmber(String phoneUmber) {
        this.phoneUmber = phoneUmber;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getProfileImage() {
        return profileImage;
    }

    public void setProfileImage(String profileImage) {
        this.profileImage = profileImage;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getProfession() {
        return profession;
    }

    public void setProfession(String profession) {
        this.profession = profession;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }
}
