package com.arm.appointmentapp.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.arm.appointmentapp.R;
import com.arm.appointmentapp.model.CategoryModel;
import com.arm.appointmentapp.model.ProfessionModel;
import com.arm.appointmentapp.databinding.ItemProfessionLayoutBinding;
import com.arm.appointmentapp.model.UserModel;
import com.bumptech.glide.Glide;

import java.util.ArrayList;

public class ProfessionsAdapter extends RecyclerView.Adapter<ProfessionsAdapter.ViewHolderClass> {

    Context mContext;
    ArrayList<UserModel> professionModels;
    OnProfessionItemClickListener professionItemClickListener;

    public ProfessionsAdapter(Context mContext, ArrayList<UserModel> professionModels, OnProfessionItemClickListener professionItemClickListener) {
        this.mContext = mContext;
        this.professionModels = professionModels;
        this.professionItemClickListener = professionItemClickListener;
    }

    @NonNull
    @Override
    public ViewHolderClass onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mContext).inflate(R.layout.item_profession_layout, parent, false);

        return new ViewHolderClass(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolderClass holder, int position) {

        UserModel professionModel = professionModels.get(position);
        holder.binding.categorName.setText(professionModel.getCategory());
        holder.binding.name.setText(professionModel.getName());
        holder.binding.description.setText(professionModel.getUserDescription());

        Glide.with(mContext)
                .load(professionModel.getProfileImage())
                .centerCrop()
                .placeholder(R.drawable.ic_user_profile_image)
                .into(holder.binding.profileImage);

        holder.binding.getRoot().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                professionItemClickListener.onItemClick(professionModel);
            }
        });

    }

    @Override
    public int getItemCount() {
        return professionModels.size();
    }

    public static class ViewHolderClass extends RecyclerView.ViewHolder {
        ItemProfessionLayoutBinding binding;

        public ViewHolderClass(@NonNull View itemView) {
            super(itemView);
            binding = ItemProfessionLayoutBinding.bind(itemView);
        }
    }

    public interface OnProfessionItemClickListener {
        void onItemClick(UserModel professionModel);
    }


    // method for filtering our recyclerview items.
    public void filterList(ArrayList<UserModel> filterlist) {
        // below line is to add our filtered
        // list in our course array list.
        professionModels= filterlist;
        // below line is to notify our adapter
        // as change in recycler view data.
        notifyDataSetChanged();
    }

}
