package com.arm.appointmentapp.model;

public class MyApointMentModel {

    private String id;
    private String patientName;
    private String profileImage;
    private String patientId;
    private String timeAppointment;
    private String dateAppointment;


    public MyApointMentModel() {

    }

    public MyApointMentModel(String id, String patientName, String profileImage, String patientId, String timeAppointment, String dateAppointment) {
        this.id = id;
        this.patientName = patientName;
        this.profileImage = profileImage;
        this.patientId = patientId;
        this.timeAppointment = timeAppointment;
        this.dateAppointment = dateAppointment;
    }

    public String getId() {
        return id;
    }

    public String getPatientName() {
        return patientName;
    }

    public String getProfileImage() {
        return profileImage;
    }

    public String getPatientId() {
        return patientId;
    }

    public String getTimeAppointment() {
        return timeAppointment;
    }

    public String getDateAppointment() {
        return dateAppointment;
    }
}

