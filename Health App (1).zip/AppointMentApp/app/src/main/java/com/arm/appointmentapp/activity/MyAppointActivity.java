package com.arm.appointmentapp.activity;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.PopupMenu;
import android.widget.Toast;

import com.arm.appointmentapp.R;
import com.arm.appointmentapp.adapter.MyApointMentAdapter;
import com.arm.appointmentapp.databinding.ActivityMyAppointBinding;
import com.arm.appointmentapp.model.MyApointMentModel;
import com.arm.appointmentapp.model.MyBokingModel;
import com.arm.appointmentapp.utils.Utils;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QuerySnapshot;
import com.kaopiz.kprogresshud.KProgressHUD;

import java.util.ArrayList;

public class MyAppointActivity extends AppCompatActivity implements MyApointMentAdapter.OnItemClickListener {

    ActivityMyAppointBinding binding;
    ArrayList<MyApointMentModel> myApointMentModelArrayList;
    MyApointMentAdapter myApointMentAdapter;
    KProgressHUD progressHUD;
    AlertDialog alertDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMyAppointBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        progressHUD = Utils.intiDialog(this, progressHUD);
        myApointMentModelArrayList = new ArrayList<>();
        myApointMentAdapter = new MyApointMentAdapter(this, myApointMentModelArrayList, this);

        setUpRecyclerView();


        binding.backIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

        binding.mMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showPopupMenu(view);
            }
        });
    }


    private void setUpRecyclerView() {
        progressHUD.show();
        FirebaseFirestore.getInstance().collection("MyAppointMents").document(FirebaseAuth.getInstance().getUid()).collection("allPatientsAppointMents").addSnapshotListener(new EventListener<QuerySnapshot>() {
            @Override
            public void onEvent(@Nullable QuerySnapshot value, @Nullable FirebaseFirestoreException error) {
                progressHUD.dismiss();
                if (!value.isEmpty()) {
                    myApointMentModelArrayList.clear();
                    for (DocumentSnapshot documentSnapshot : value.getDocuments()) {
                        MyApointMentModel myApointMentModel = documentSnapshot.toObject(MyApointMentModel.class);
                        myApointMentModelArrayList.add(myApointMentModel);
                    }
                    binding.myBookingList.setAdapter(myApointMentAdapter);
                    myApointMentAdapter.notifyDataSetChanged();
                    Log.d("SetUpRecyclerView", "Size: " + myApointMentModelArrayList.size());
                    binding.empty.setVisibility(View.GONE);

                } else {
                    binding.empty.setVisibility(View.VISIBLE);
                    Log.d("SetUpRecyclerView", "EMPTY ERROR: ");
                }
            }
        });

    }


    @Override
    public void onCancelBooking(int pos) {
        confirmDialog(pos);
    }


    private void confirmDialog(int index) {
        alertDialog = new AlertDialog.Builder(this)
                .setIcon(android.R.drawable.ic_dialog_alert)
                .setTitle("Cancel Appointment")
                .setMessage("Are you sure to cancel the appointment with doctor?")
                .setPositiveButton("YES", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        alertDialog.dismiss();
                        deleteBooking(index);

                    }
                }).setNegativeButton("NO", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        alertDialog.dismiss();
                    }
                })
                .show();
    }


    private void deleteBooking(int i) {
        FirebaseFirestore.getInstance().collection("MyAppointMents").document(FirebaseAuth.getInstance().getUid()).collection("allPatientsAppointMents").document(myApointMentModelArrayList.get(i).getId()).delete().addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if (task.isSuccessful()) {
                    Toast.makeText(MyAppointActivity.this, "appointment canceled", Toast.LENGTH_SHORT).show();
                    myApointMentModelArrayList.remove(i);
                    myApointMentAdapter.notifyDataSetChanged();
                }
            }
        });
    }


    private void showPopupMenu(View view) {
        PopupMenu popupMenu = new PopupMenu(MyAppointActivity.this, view);
        popupMenu.getMenuInflater().inflate(R.menu.prof_menu, popupMenu.getMenu());
        popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem menuItem) {
                switch (menuItem.getItemId()) {
                    case R.id.logOut:

                        FirebaseAuth.getInstance().signOut();
                        startActivity(new Intent(MyAppointActivity.this, FirstActivity.class));
                        finish();

                        return true;

                    case R.id.myProfile:
                        startActivity(new Intent(MyAppointActivity.this, DetailActivity.class)
                                .putExtra("profile","profile"));
                        return true;
                }
                return false;
            }
        });
        popupMenu.show();
    }
}