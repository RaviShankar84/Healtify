package com.arm.appointmentapp.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.arm.appointmentapp.R;
import com.arm.appointmentapp.adapter.ProfessionsAdapter;
import com.arm.appointmentapp.databinding.ActivitySearchBinding;
import com.arm.appointmentapp.databinding.ActivityServicesBinding;
import com.arm.appointmentapp.model.UserModel;

import org.checkerframework.checker.units.qual.A;

import java.util.ArrayList;

public class SearchActivity extends AppCompatActivity {

    ActivitySearchBinding binding;
    ArrayList<UserModel> userModelArrayList;
    ProfessionsAdapter professionsAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivitySearchBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.backIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

        Intent intent = getIntent();
        userModelArrayList = (ArrayList<UserModel>) intent.getSerializableExtra("professionList");

        if (userModelArrayList == null) {
            return;
        }

        setAdapter();
        binding.mSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                filter(charSequence.toString());
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

    }


    private void filter(String text) {
        // creating a new array list to filter our data.
        ArrayList<UserModel> filteredlist = new ArrayList<UserModel>();

        // running a for loop to compare elements.
        for (UserModel item : userModelArrayList) {
            // checking if the entered string matched with any item of our recycler view.
            if (item.getName().toLowerCase().contains(text.toLowerCase())) {
                // if the item is matched we are
                // adding it to our filtered list.
                filteredlist.add(item);
            }
        }
        if (filteredlist.isEmpty()) {
            // if no item is added in filtered list we are
            // displaying a toast message as no data found.
            Toast.makeText(this, "No Data Found..", Toast.LENGTH_SHORT).show();
        }
        professionsAdapter.filterList(filteredlist);

    }

    private void setAdapter() {

        professionsAdapter = new ProfessionsAdapter(this, userModelArrayList, professionModel -> {
            Intent intent1 = new Intent(SearchActivity.this, DetailActivity.class);
            intent1.putExtra("userModel", professionModel);
            intent1.putExtra("profile", "");
            startActivity(intent1);
        });

        binding.mPRecylerView.setAdapter(professionsAdapter);

    }
}