package com.arm.appointmentapp.activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.arm.appointmentapp.databinding.ActivityAppointMentBinding;
import com.arm.appointmentapp.databinding.ActivityCategoryBinding;
import com.arm.appointmentapp.databinding.ActivityDetailBinding;
import com.arm.appointmentapp.databinding.ActivityMyAppointBinding;
import com.arm.appointmentapp.databinding.ActivityMyBokingsBinding;
import com.arm.appointmentapp.databinding.ActivitySearchBinding;
import com.arm.appointmentapp.databinding.ActivtiyWelcomeBinding;
import com.arm.appointmentapp.model.UserModel;
import com.arm.appointmentapp.prefrence.PrefUtil;
import com.arm.appointmentapp.utils.GoogleLoginManager;
import com.arm.appointmentapp.utils.Utils;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.GoogleAuthProvider;
import com.google.firebase.firestore.FirebaseFirestore;
import com.kaopiz.kprogresshud.KProgressHUD;

import java.util.HashMap;

public class ActivtiyWelcome extends AppCompatActivity {

    ActivtiyWelcomeBinding binding;
    private static final int RC_SIGN_IN = 101;
    private static final String TAG = "ActivtiyWelcome";
    FirebaseAuth mAuth;
    GoogleLoginManager googleLoginManager;
    KProgressHUD progressHUD;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivtiyWelcomeBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        progressHUD = Utils.intiDialog(ActivtiyWelcome.this, progressHUD);

        googleLoginManager = new GoogleLoginManager(this);

        // [START initialize_auth]
        // Initialize Firebase Auth
        mAuth = FirebaseAuth.getInstance();
        // [END initialize_auth]

        binding.loginTv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(ActivtiyWelcome.this, LoginActivity.class));
                finish();
            }
        });


        binding.googleLoginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (PrefUtil.getInstance(ActivtiyWelcome.this).getUserApp().equals("providerApp")) {
                    Toast.makeText(ActivtiyWelcome.this, "provider can't use google login", Toast.LENGTH_SHORT).show();
                    return;
                }
                signIn();
            }
        });
    }

    private void signIn() {
        googleLoginManager.onLogin();
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (FirebaseAuth.getInstance().getCurrentUser() != null) {
            if (PrefUtil.getInstance(this).getUserApp().equals("userApp")) {
                startActivity(new Intent(ActivtiyWelcome.this, ServicesActivity.class));
                finish();
            } else {
                startActivity(new Intent(ActivtiyWelcome.this, MyAppointActivity.class));
                finish();
            }
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK && requestCode == RC_SIGN_IN) {
            Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);
            try {
                // Google Sign In was successful, authenticate with Firebase
                GoogleSignInAccount account = task.getResult(ApiException.class);
                Log.d(TAG, "firebaseAuthWithGoogle:" + account.getId());
                firebaseAuthWithGoogle(account.getIdToken());
            } catch (ApiException e) {
                // Google Sign In failed, update UI appropriately
                Log.w(TAG, "Google sign in failed", e);
            }
        }

    }

    private void firebaseAuthWithGoogle(String idToken) {
        AuthCredential credential = GoogleAuthProvider.getCredential(idToken, null);
        mAuth.signInWithCredential(credential)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // Sign in success, update UI with the signed-in user's information
                            Log.d(TAG, "signInWithCredential:success");
                            FirebaseUser user = mAuth.getCurrentUser();

                            uploadUserData(user);
                        } else {
                            // If sign in fails, display a message to the user.
                            Log.w(TAG, "signInWithCredential:failure", task.getException());
                            progressHUD.dismiss();

                        }
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        progressHUD.dismiss();

                    }
                });
    }


    public void uploadUserData(FirebaseUser firebaseUser) {
        progressHUD.show();
        UserModel userModel = new UserModel();
        String id = FirebaseAuth.getInstance().getUid();
        userModel.setUserId(firebaseUser.getUid());
        userModel.setEmail(firebaseUser.getEmail());
        userModel.setProfileImage(firebaseUser.getPhotoUrl().toString());
        userModel.setPhoneUmber(firebaseUser.getPhoneNumber());
        userModel.setName(firebaseUser.getDisplayName());

        // Todo __________________________________________________FireBase Code here________________________________________________
        FirebaseFirestore.getInstance().collection("users").document(id).set(userModel).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void unused) {
                progressHUD.dismiss();
                if (PrefUtil.getInstance(ActivtiyWelcome.this).getUserApp().equals("userApp")) {
                    Intent intent = new Intent(ActivtiyWelcome.this, ServicesActivity.class);
                    startActivity(intent);
                    finish();
                    PrefUtil.getInstance(ActivtiyWelcome.this).setLogin("userApp");
                } else {
                    Intent intent = new Intent(ActivtiyWelcome.this, MyAppointActivity.class);
                    startActivity(intent);
                    finish();
                    PrefUtil.getInstance(ActivtiyWelcome.this).setLogin("providerApp");
                }
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(ActivtiyWelcome.this, e.getMessage() + "", Toast.LENGTH_SHORT).show();
                progressHUD.dismiss();

            }
        });

    }
}