package com.arm.appointmentapp.model;

public class ProfessionModel {

    private String name;
    private int profileImage;
    private String categoryName;
    private String description;

    public ProfessionModel() {
    }

    public ProfessionModel(String name, int profileImage, String categoryName, String description) {
        this.name = name;
        this.profileImage = profileImage;
        this.categoryName = categoryName;
        this.description = description;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getProfileImage() {
        return profileImage;
    }

    public void setProfileImage(int profileImage) {
        this.profileImage = profileImage;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}

