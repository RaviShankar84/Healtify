package com.arm.appointmentapp.prefrence;

import android.content.Context;
import android.content.SharedPreferences;

public class PrefUtil {


    private static PrefUtil sharePref = new PrefUtil();
    private static SharedPreferences sharedPreferences;
    private static SharedPreferences.Editor editor;


    private static final String USER_APP = "name";
    private static final String USER_LOGIN = "login";

    //prevent creating multiple instances by making the constructor private
    private PrefUtil() {
    }

    //The context passed into the getInstance should be application level context.
    public static PrefUtil getInstance(Context context) {
        if (sharedPreferences == null) {
            sharedPreferences = context.getSharedPreferences(context.getPackageName(), Context.MODE_PRIVATE);
            editor = sharedPreferences.edit();
        }
        return sharePref;
    }

    public void setUserApp(String name) {
        editor.putString(USER_APP, name);
        editor.commit();
    }


    public String getUserApp() {
        return sharedPreferences.getString(USER_APP, "");
    }

    public void setLogin(String name) {
        editor.putString(USER_LOGIN, name);
        editor.commit();
    }

    public String getLogin() {
        return sharedPreferences.getString(USER_LOGIN, "");
    }
}