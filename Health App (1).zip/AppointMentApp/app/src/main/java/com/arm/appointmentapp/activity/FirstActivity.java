package com.arm.appointmentapp.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.arm.appointmentapp.databinding.ActivityFirstBinding;
import com.arm.appointmentapp.prefrence.PrefUtil;
import com.google.firebase.auth.FirebaseAuth;

public class FirstActivity extends AppCompatActivity {

    ActivityFirstBinding _mBinding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        _mBinding = ActivityFirstBinding.inflate(getLayoutInflater());
        setContentView(_mBinding.getRoot());

        _mBinding.userApp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                PrefUtil.getInstance(FirstActivity.this).setUserApp("userApp");
                goToWelcomeScren();
            }
        });

        _mBinding.mProfession.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                PrefUtil.getInstance(FirstActivity.this).setUserApp("providerApp");
                goToWelcomeScren();
            }
        });
    }

    private void goToWelcomeScren() {
        Intent intent = new Intent(this, ActivtiyWelcome.class);
        startActivity(intent);
    }
}