package com.arm.appointmentapp.adapter;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.arm.appointmentapp.R;
import com.arm.appointmentapp.databinding.ItemCategoryBinding;
import com.arm.appointmentapp.model.CategoryModel;

import java.util.ArrayList;

public class CategoryAdapter extends RecyclerView.Adapter<CategoryAdapter.ViewHolderClass> {


    Context mContext;
    ArrayList<String> arrayList;
    OnCategoryClickItem onCategoryClickItem;
    int row_index = 0;

    public CategoryAdapter(Context mContext, ArrayList<String> arrayList, OnCategoryClickItem onCategoryClickItem) {
        this.mContext = mContext;
        this.arrayList = arrayList;
        this.onCategoryClickItem = onCategoryClickItem;
    }

    @NonNull
    @Override
    public ViewHolderClass onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(mContext).inflate(R.layout.item_category, parent, false);

        return new ViewHolderClass(view);
    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolderClass holder, int position) {

        holder.binding.categorName.setText(arrayList.get(position));

        holder.binding.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onCategoryClickItem.onClickCategoryItem(arrayList.get(position), position);
                row_index = position;
                notifyDataSetChanged();
            }
        });

        if (row_index == position) {
            holder.binding.categorName.setBackgroundResource(R.drawable.category_btn_bg);
            holder.binding.categorName.setTextColor(ContextCompat.getColor(mContext,R.color.white));
        } else {
            holder.binding.categorName.setBackgroundResource(R.drawable.category_white_bg);
            holder.binding.categorName.setTextColor(Color.parseColor("#828A89"));

        }


    }


    public static class ViewHolderClass extends RecyclerView.ViewHolder {

        ItemCategoryBinding binding;

        public ViewHolderClass(@NonNull View itemView) {
            super(itemView);
            binding = ItemCategoryBinding.bind(itemView);
        }
    }

    public interface OnCategoryClickItem {
        void onClickCategoryItem(String mCategoryName, int pos);
    }

}
