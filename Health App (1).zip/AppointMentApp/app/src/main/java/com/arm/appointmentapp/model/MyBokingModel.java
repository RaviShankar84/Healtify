package com.arm.appointmentapp.model;

public class MyBokingModel {

    private String id;
    private String name;
    private String categoryName;
    private String profession;
    private String description;
    private String profileImage;
    private String patientId;
    private String doctorId;
    private String patientName;
    private String bookingTime;
    private String date;

    public MyBokingModel() {

    }


    public MyBokingModel(String id, String name, String categoryName, String profession, String description, String profileImage, String patientId, String doctorId, String patientName, String bookingTime, String date) {
        this.id = id;
        this.name = name;
        this.categoryName = categoryName;
        this.profession = profession;
        this.description = description;
        this.profileImage = profileImage;
        this.patientId = patientId;
        this.doctorId = doctorId;
        this.patientName = patientName;
        this.bookingTime = bookingTime;
        this.date = date;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public String getProfession() {
        return profession;
    }

    public String getDescription() {
        return description;
    }

    public String getProfileImage() {
        return profileImage;
    }

    public String getPatientId() {
        return patientId;
    }

    public String getDoctorId() {
        return doctorId;
    }

    public String getPatientName() {
        return patientName;
    }

    public String getBookingTime() {
        return bookingTime;
    }

    public String getDate() {
        return date;
    }
}
