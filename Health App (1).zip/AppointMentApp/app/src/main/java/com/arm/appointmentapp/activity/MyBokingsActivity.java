package com.arm.appointmentapp.activity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.arm.appointmentapp.adapter.MyBookingAdapter;
import com.arm.appointmentapp.databinding.ActivityMyBokingsBinding;
import com.arm.appointmentapp.model.MyBokingModel;
import com.arm.appointmentapp.utils.Utils;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QuerySnapshot;
import com.kaopiz.kprogresshud.KProgressHUD;

import java.util.ArrayList;

public class MyBokingsActivity extends AppCompatActivity implements MyBookingAdapter.OnItemClickListener {

    ActivityMyBokingsBinding binding;
    ArrayList<MyBokingModel> myBokingModelArrayList;
    MyBookingAdapter myBookingAdapter;
    KProgressHUD progressHUD;
    AlertDialog alertDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMyBokingsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        progressHUD = Utils.intiDialog(this, progressHUD);

        myBokingModelArrayList = new ArrayList<>();
        myBookingAdapter = new MyBookingAdapter(this, myBokingModelArrayList, this);

        setUpRecyclerView();




        binding.backIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

    }

    private void setUpRecyclerView() {
        progressHUD.show();
        FirebaseFirestore.getInstance().collection("MyBookings").document(FirebaseAuth.getInstance().getUid()).collection("bookings").addSnapshotListener(new EventListener<QuerySnapshot>() {
            @Override
            public void onEvent(@Nullable QuerySnapshot value, @Nullable FirebaseFirestoreException error) {
                progressHUD.dismiss();
                if (!value.isEmpty()) {
                    myBokingModelArrayList.clear();
                    for (DocumentSnapshot documentSnapshot : value.getDocuments()) {
                        MyBokingModel myBokingModel = documentSnapshot.toObject(MyBokingModel.class);
                        myBokingModelArrayList.add(myBokingModel);
                        Log.d("SetUpRecyclerView", "TIME: " + myBokingModel.getBookingTime());
                    }
                    binding.myBookingList.setAdapter(myBookingAdapter);
                    myBookingAdapter.notifyDataSetChanged();
                    Log.d("SetUpRecyclerView", "Size: " + myBokingModelArrayList.size());
                    binding.empty.setVisibility(View.GONE);
                } else {
                    binding.empty.setVisibility(View.VISIBLE);
                    Log.d("SetUpRecyclerView", "EMPTY ERROR: ");
                }
            }
        });


    }


    @Override
    public void onCancelBookClick(MyBokingModel myBokingModel) {
        confirmDialog(myBokingModel);
    }


    private void confirmDialog(MyBokingModel myBokingModel) {
        alertDialog = new AlertDialog.Builder(this)
                .setIcon(android.R.drawable.ic_dialog_alert)
                .setTitle("Cancel Appointment")
                .setMessage("Are you sure to cancel the appointment with doctor?")
                .setPositiveButton("YES", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        alertDialog.dismiss();
                        deleteBooking(myBokingModel);

                    }
                }).setNegativeButton("NO", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        alertDialog.dismiss();
                    }
                })
                .show();
    }

    private void deleteBooking(MyBokingModel myBokingModel) {
        FirebaseFirestore.getInstance().collection("MyBookings").document(FirebaseAuth.getInstance().getUid()).collection("bookings").document(myBokingModel.getId()).delete().addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if (task.isSuccessful()) {
                    Toast.makeText(MyBokingsActivity.this, "booking canceled", Toast.LENGTH_SHORT).show();
                    myBokingModelArrayList.remove(myBokingModel);
                    myBookingAdapter.notifyDataSetChanged();
                }
            }
        });
    }


}