package com.arm.appointmentapp.model;

public class CategoryModel {

    private String categorName;


    public CategoryModel() {

    }


    public CategoryModel(String categorName, int id) {
        this.categorName = categorName;
    }

    public String getCategorName() {
        return categorName;
    }

    public void setCategorName(String categorName) {
        this.categorName = categorName;
    }

}
