package com.arm.appointmentapp.activity;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import com.arm.appointmentapp.R;
import com.arm.appointmentapp.adapter.ProfessionsAdapter;
import com.arm.appointmentapp.databinding.ActivityDetailBinding;
import com.arm.appointmentapp.model.UserModel;
import com.bumptech.glide.Glide;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.Objects;

public class DetailActivity extends AppCompatActivity {
    ActivityDetailBinding binding;
    UserModel userModel;
    String name, profile;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityDetailBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        Intent intent = getIntent();
        if (intent != null) {
            userModel = (UserModel) intent.getSerializableExtra("userModel");
            name = intent.getStringExtra("name");
            profile = intent.getStringExtra("profile");
            if (profile.isEmpty()) {
                binding.name.setText(userModel.getName());
                binding.categorName.setText(userModel.getCategory());
                binding.description.setText(userModel.getUserDescription());

                Glide.with(this)
                        .load(userModel.getProfileImage())
                        .centerCrop()
                        .placeholder(R.drawable.ic_user_profile_image)
                        .into(binding.profileImage);
            } else {
                binding.BtnAppoinMnt.setVisibility(View.GONE);
                setUpProfile();
            }

        }

        binding.backIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });


        binding.BtnAppoinMnt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(DetailActivity.this, AppointMentActivity.class);
                intent.putExtra("userModel", userModel);
                intent.putExtra("name", name);
                startActivity(intent);
            }
        });
    }


    private void setUpProfile() {
        FirebaseFirestore.getInstance().collection("users").addSnapshotListener((value, error) -> {
            UserModel userModel = null;
            for (DocumentSnapshot documentSnapshot : value.getDocuments()) {
                userModel = documentSnapshot.toObject(UserModel.class);
                try {
                    setUserProfile(userModel);
                } catch (Exception ignored) {
                    ignored.printStackTrace();
                }
            }
        });

    }

    private void setUserProfile(UserModel userModel) {
        if (Objects.equals(FirebaseAuth.getInstance().getUid(), userModel.getUserId())) {
            Glide.with(DetailActivity.this)
                    .load(userModel.getProfileImage())
                    .centerCrop()
                    .placeholder(R.drawable.ic_user_profile_image)
                    .into(binding.profileImage);
            binding.name.setText(userModel.getName());
            binding.description.setText(userModel.getUserDescription());
            binding.categorName.setText(userModel.getCategory());

        }
    }
}