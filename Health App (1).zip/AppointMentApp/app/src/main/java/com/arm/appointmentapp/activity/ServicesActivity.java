package com.arm.appointmentapp.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.arm.appointmentapp.databinding.ActivityServicesBinding;

public class ServicesActivity extends AppCompatActivity {

    ActivityServicesBinding binding;


    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityServicesBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());


        binding.doctorTv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                goToMainActivity("Doctors");
            }
        });

        binding.gymTranerTv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                goToMainActivity("Gym Trainer");
            }
        });


        binding.sportCoachTv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                goToMainActivity("Sports");
            }
        });

    }

    private void goToMainActivity(String categoryName) {
        Intent intent = new Intent(ServicesActivity.this, CategoryActivity.class);
        intent.putExtra("mProfessionName", categoryName);
        startActivity(intent);
    }

    ;
}