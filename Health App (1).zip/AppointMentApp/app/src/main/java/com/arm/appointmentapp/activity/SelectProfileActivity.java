package com.arm.appointmentapp.activity;

import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.arm.appointmentapp.databinding.ActivityRegisterBinding;
import com.arm.appointmentapp.databinding.ActivitySelectProfileBinding;
import com.arm.appointmentapp.model.UserModel;
import com.arm.appointmentapp.prefrence.PrefUtil;
import com.arm.appointmentapp.utils.Utils;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.kaopiz.kprogresshud.KProgressHUD;

public class SelectProfileActivity extends AppCompatActivity {

    ActivitySelectProfileBinding binding;
    UserModel userModel;
    Uri imageUri;
    FirebaseStorage firebaseStorage;
    KProgressHUD progressHUD;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivitySelectProfileBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        firebaseStorage = FirebaseStorage.getInstance();
        progressHUD = Utils.intiDialog(SelectProfileActivity.this, progressHUD);
        Intent intent = getIntent();
        if (intent != null) {
            userModel = (UserModel) intent.getSerializableExtra("userModel");
            Log.d("userModel", userModel.getEmail());
            Log.d("userModel", userModel.getName());
            Log.d("userModel", userModel.getPassword());

        }
        binding.submitBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                uploadDataToFirebase(userModel);
            }
        });

        binding.profileImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mGetContent.launch("image/*");
            }
        });

    }

    ActivityResultLauncher<String> mGetContent = registerForActivityResult(new ActivityResultContracts.GetContent(), new ActivityResultCallback<Uri>() {
        @Override
        public void onActivityResult(Uri result) {
            if (result != null) {
                binding.profileImage.setImageURI(result);
                imageUri = result;
            }
        }
    });

    private void uploadDataToFirebase(UserModel userModel) {
        progressHUD.show();
        StorageReference storageReference = firebaseStorage.getReference("Profile").child(FirebaseAuth.getInstance().getUid());

        storageReference.putFile(imageUri).addOnCompleteListener(new OnCompleteListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<UploadTask.TaskSnapshot> task) {
                if (task.isSuccessful()) {
                    storageReference.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                        @Override
                        public void onSuccess(Uri uri) {
                            userModel.setProfileImage(uri.toString());
                            uploadUserData();
                        }
                    }).addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Toast.makeText(SelectProfileActivity.this, e.getMessage() + "", Toast.LENGTH_SHORT).show();
                            progressHUD.dismiss();
                        }
                    });
                }
            }
        });
    }

    public void uploadUserData() {

        // Todo __________________________________________________FireBase Code here________________________________________________
        String id = FirebaseAuth.getInstance().getUid();
        FirebaseFirestore.getInstance().collection("users").document(id).set(userModel).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void unused) {
                progressHUD.dismiss();
                if (PrefUtil.getInstance(SelectProfileActivity.this).getUserApp().equals("userApp")) {
                    Intent intent = new Intent(SelectProfileActivity.this, ServicesActivity.class);
                    startActivity(intent);
                    finish();
                    PrefUtil.getInstance(SelectProfileActivity.this).setLogin("userApp");
                } else {
                    Intent intent = new Intent(SelectProfileActivity.this, MyAppointActivity.class);
                    startActivity(intent);
                    finish();
                    PrefUtil.getInstance(SelectProfileActivity.this).setLogin("providerApp");

                }
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(SelectProfileActivity.this, e.getMessage() + "", Toast.LENGTH_SHORT).show();
                progressHUD.dismiss();

            }
        });

    }
}