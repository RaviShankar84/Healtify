package com.arm.appointmentapp.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.arm.appointmentapp.R;
import com.arm.appointmentapp.databinding.ItemMyAppointmentBinding;
import com.arm.appointmentapp.model.MyApointMentModel;

import java.util.ArrayList;

public class MyApointMentAdapter extends RecyclerView.Adapter<MyApointMentAdapter.MyViewHolder> {

    Context mContext;
    ArrayList<MyApointMentModel> myApointMentModelArrayList;
    OnItemClickListener onItemClickListener;

    public MyApointMentAdapter(Context mContext, ArrayList<MyApointMentModel> myApointMentModelArrayList, OnItemClickListener onItemClickListener) {
        this.mContext = mContext;
        this.myApointMentModelArrayList = myApointMentModelArrayList;
        this.onItemClickListener = onItemClickListener;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mContext).inflate(R.layout.item_my_appointment, parent, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {

        MyApointMentModel model = myApointMentModelArrayList.get(position);
        holder.binding.patientName.setText(model.getPatientName());
        holder.binding.dateTime.setText(model.getDateAppointment());
        holder.binding.time.setText(model.getTimeAppointment());

        holder.binding.cancelBoking.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onItemClickListener.onCancelBooking(position);
            }
        });
    }

    @Override
    public int getItemCount() {
        return myApointMentModelArrayList.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder {

        ItemMyAppointmentBinding binding;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            binding = ItemMyAppointmentBinding.bind(itemView);
        }
    }

    public interface OnItemClickListener {
        void onCancelBooking(int position);
    }
}
